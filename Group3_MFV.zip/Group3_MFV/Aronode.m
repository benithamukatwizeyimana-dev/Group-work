% Aron ODE system (Model 4)
function ds = Aronode(a,s,theta)

p = s(1);
r = s(2);
g = s(3);

v     = theta(1);
rb    = theta(2);
beta  = theta(3);
delta = theta(4);

dp = v - (r + rb)*p;
dr = 0.2*p - beta*r;
dg = 0.5*p*exp(-(r + rb)) - delta*g;

ds = [dp; dr; dg];
end
