function ss = aron_ss_only(theta, data)
% SSQ for Aron model: uses all three outputs p,r,g

alpha = data(:,1);
Yobs  = data(:,2:4);   % [p r g]
y0 = [1;0;0];

[Yhat,~] = Aronmodel(alpha, theta, y0);

R = Yobs - Yhat;
ss = sum(sum(R.^2));
end
