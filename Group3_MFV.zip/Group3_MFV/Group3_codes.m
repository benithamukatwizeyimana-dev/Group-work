clear all; close all; clc;

%% Age grid (observation points)
alpha = (0:1:25)';

%% True parameters (given in the project)
theta_true = [6 0.66 0.005 0.4];   % [v rb beta delta]

%% Initial condition
y0 = [1; 0; 0];

%% Generate noise-free truth
[Ytrue,~] = Aronmodel(alpha, theta_true, y0);  % n x 3

%% Generate synthetic noisy data
sigma = 0.05;                         % choose noise level
Yobs = Ytrue + sigma*randn(size(Ytrue));

%% Data matrix (class style)
% columns: [alpha, p_obs, r_obs, g_obs]
data = [alpha, Yobs];

%% Parameter estimation (LSQ) using fminsearch
theta0 = [5 0.5 0.01 0.3];            % initial guess
[theta_hat, ssmin] = fminsearch(@aronss, theta0, [], data);

disp('theta_hat = [v, rb, beta, delta]:');
disp(theta_hat);
disp(['SSQ = ', num2str(ssmin)]);

%% Estimate sigma^2 from residual SSQ
n = length(alpha);
N = 3*n;            % p,r,g all used
p = 4;              % number of parameters
sigma2_hat = ssmin/(N - p);
disp(['sigma2_hat = ', num2str(sigma2_hat)]);

%% Numerical Jacobian using EXACT class jacob.m
% aronsim returns n x 3 and jacob stacks it into (3n) x 4
J = jacob(@aronsim, alpha, theta_hat, [1e-6 1e-12]);

%% Covariance matrix
C = sigma2_hat * inv(J'*J);

disp('Covariance matrix C:');
disp(C);

std_theta = sqrt(diag(C));
tvals = theta_hat(:)./std_theta;

disp('(theta, std, t-values):');
disp([theta_hat(:), std_theta, tvals]);

%% Plot 1: True (line) vs Noisy data (circles)
figure;
subplot(1,3,1); hold on;
plot(alpha, Ytrue(:,1), '-'); plot(alpha, Yobs(:,1), 'o');
xlabel('\alpha'); ylabel('p'); title('True vs Data: p'); legend('True','Data');

subplot(1,3,2); hold on;
plot(alpha, Ytrue(:,2), '-'); plot(alpha, Yobs(:,2), 'o');
xlabel('\alpha'); ylabel('r'); title('True vs Data: r'); legend('True','Data');

subplot(1,3,3); hold on;
plot(alpha, Ytrue(:,3), '-'); plot(alpha, Yobs(:,3), 'o');
xlabel('\alpha'); ylabel('g'); title('True vs Data: g'); legend('True','Data');

%% Plot 2: Fit (line) vs Noisy data (circles)
[Yfit,~] = Aronmodel(alpha, theta_hat, y0);

figure;
subplot(1,3,1); hold on;
plot(alpha, Yfit(:,1), '-'); plot(alpha, Yobs(:,1), 'o');
xlabel('\alpha'); ylabel('p'); title('Fit vs Data: p'); legend('Fit','Data');

subplot(1,3,2); hold on;
plot(alpha, Yfit(:,2), '-'); plot(alpha, Yobs(:,2), 'o');
xlabel('\alpha'); ylabel('r'); title('Fit vs Data: r'); legend('Fit','Data');

subplot(1,3,3); hold on;
plot(alpha, Yfit(:,3), '-'); plot(alpha, Yobs(:,3), 'o');
xlabel('\alpha'); ylabel('g'); title('Fit vs Data: g'); legend('Fit','Data');





addpath("mcmcstat-master")
%% MCMC model definition
model.ssfun = @aron_ss_only; % sum-of-squares function
model.sigma2 = sigma2_hat; % measurement error variance

%% Parameter structure: {name, init, min, max}
params = {
{'v', theta_hat(1), 0}
{'r_{b}', theta_hat(2), 0}
{'\beta', theta_hat(3), 0}
{'\delta', theta_hat(4), 0}
};
%% MCMC options
options.nsimu = 20000; % number of samples
options.qcov = 0.01*eye(4); % initial proposal covariance
options.method = 'am'; % AM sampler
options.adaptint = 100; % adaptation interval
%% Run MCMC
[results, chain] = mcmcrun(model, data, params, options);

%% Chain plots
figure;
mcmcplot(chain, [], results.names, 'chainpanel');
figure;
mcmcplot(chain, [], results.names, 'pairs');
%% Chain statistics + autocorrelation
chainstats(chain, results);
figure;
mcmcplot(chain, [], results.names, 'acf', 100);
%% Predictive distribution
xx = linspace(0,40,100)'; % prediction grid (column vector)
out = mcmcpred(results, chain, [], xx, @Aronmodel, 500,y0); % use 500 sampled parameter sets
figure;
mcmcpredplot(out);
titles = {'Predictive distribution for p(\alpha)', ...
          'Predictive distribution for r(\alpha)', ...
          'Predictive distribution for g(\alpha)'};

