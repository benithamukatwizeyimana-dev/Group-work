function Y = aronsim(alpha, theta)

y0 = [1; 0; 0];
[Y,~] = Aronmodel(alpha, theta, y0);  % Aronmodel returns [y,t], we keep y
end
