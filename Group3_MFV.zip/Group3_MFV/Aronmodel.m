% create a function that solves the Aron ODE
function [y,t] = Aronmodel(alpha,theta,y0)
[t,y] = ode23(@Aronode, alpha, y0, [], theta);
end
