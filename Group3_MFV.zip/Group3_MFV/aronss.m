% Sum of squares function for Aron model (uses p,r,g)
function ss = aronss(theta, data)

alpha = data(:,1);
Yobs  = data(:,2:4);        % [p_obs r_obs g_obs]

y0 = [1; 0; 0];             % initial condition

[y,~] = Aronmodel(alpha, theta, y0);   % y is n x 3

R = Yobs - y;               % residuals for p,r,g
ss = sum(sum(R.^2));        % total SSQ across all outputs
end
